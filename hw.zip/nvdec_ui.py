"""
nvdec_ui.py  -  camera feed -> NVDEC (GPU) -> Socket.IO -> UI

Same idea as hw_v3.py (same namespaces /front /rear, same event "frame", same payload keys),
but built on the GPU reader from nvdec.py so there is no CPU decode and no CPU resize.

Run:
    python nvdec_ui.py                 # RTSP, with front/back stitch (split_concat)
    python nvdec_ui.py --no-stitch     # RTSP, no stitch  -> use this to test if stitching is the delay
    python nvdec_ui.py --file path.mp4 # offline file

Needs:  pip install python-socketio simple-websocket werkzeug PyTurboJPEG
"""
import os
import sys
import time
import base64
import argparse
import threading

import nvdec                                  # sets DLL paths, imports split_concat, defines RTSPReader
from nvdec import RTSPReader
import split_concat

import torch
import torch.nn.functional as F
import socketio
from werkzeug.serving import run_simple
from turbojpeg import TurboJPEG, TJPF_RGB

# ─────────────────────────────── config ───────────────────────────────
RTSP_URL     = "rtsp://192.168.100.10:554/rtpstream/config1"   # the rotating camera
VIDEO_PATH   = r"E:\hw_latest_videos\cam_2_h264.mp4"
PORT         = 12010                                           # same port the UI/jar already uses
OUT_W        = 2000                                            # same width hw_v3.py sends (2000x270 for stitched)
STITCH       = True                                            # True = split_concat (front/back -> 7680x1080)
ALSO_SEND_REAR = False                                         # True = also emit the same image on /rear
JPEG_QUALITY = 70
MAX_FPS      = 25                                              # cap what is sent to the UI
STATS_EVERY  = 5.0
DEBUG_FIELDS = os.environ.get("HW_DEBUG", "0") == "1"          # adds server_ts_ms to payload for ui_latency_test.html
TURBOJPEG_DLL = os.environ.get("TURBOJPEG_DLL", "C:/windows/system32/turbojpeg.dll")

jpeg = TurboJPEG(lib_path=TURBOJPEG_DLL)

# ─────────────────────────────── socket.io server ─────────────────────
# threading mode on purpose: hw_v3.py runs the GPU loop inside eventlet (monkey_patch), so a
# blocking CUDA sync / JPEG encode stalls the same hub that sends websocket frames to the UI.
sio = socketio.Server(async_mode="threading", cors_allowed_origins="*")
app = socketio.WSGIApp(sio)


def _register(ns):
    @sio.on("connect", namespace=ns)
    def _connect(sid, environ):
        print(f"connected {ns} {sid}")

    # UI toggles are accepted (so the UI/jar does not error) but this build is feed-only
    for ev in ("set_detection", "set_classification", "set_event", "set_camera_mode"):
        @sio.on(ev, namespace=ns)
        def _ignored(sid, data=None, _ev=ev, _ns=ns):
            print(f"[{_ns}] {_ev} ignored (feed-only): {data}")


_register("/front")
_register("/rear")


# ─────────────────────────────── latest-only mailbox ──────────────────
class Mailbox:
    """Holds only the newest item. A slow consumer drops frames instead of building delay."""

    def __init__(self):
        self._c = threading.Condition()
        self._item = None
        self._n = 0

    def put(self, item):
        with self._c:
            self._item = item
            self._n += 1
            self._c.notify_all()

    def get(self, last_n, timeout=0.2):
        with self._c:
            self._c.wait_for(lambda: self._n != last_n, timeout)
            return self._item, self._n


# ─────────────────────────────── GPU stage ────────────────────────────
def make_view(frame, stitch, warned):
    """frame: (H, W, 3) uint8 RGB on GPU  ->  (h, OUT_W, 3) uint8 on GPU, plus event marks."""
    ev0, ev1, ev2 = (torch.cuda.Event(enable_timing=True) for _ in range(3))
    ev0.record()

    pano = frame
    if stitch:
        if tuple(frame.shape[:2]) == (2160, 3840):
            pano = split_concat.run(frame)                 # (1080, 7680, 3)
        elif not warned[0]:
            print(f"[warn] stitch skipped: split_concat expects 3840x2160, got {tuple(frame.shape[:2][::-1])}")
            warned[0] = True
    ev1.record()

    h, w = pano.shape[:2]
    out_h = max(2, int(round(OUT_W * h / w)))              # keep aspect (stitched 7680x1080 -> 2000x270)
    x = pano.permute(2, 0, 1).unsqueeze(0).float()
    x = F.interpolate(x, size=(out_h, OUT_W), mode="bilinear", antialias=True, align_corners=False)
    out = x.squeeze(0).permute(1, 2, 0).clamp_(0, 255).to(torch.uint8).contiguous()
    ev2.record()
    return out, (ev0, ev1, ev2)


def pipeline_loop(cam, box, stop, stitch):
    torch.cuda.set_device(cam.gpu_id)
    stream = torch.cuda.Stream()
    warned = [False]
    last_seq = 0
    min_dt = 1.0 / MAX_FPS
    last_t = 0.0

    while not stop.is_set():
        frame, ts, seq = cam.wait_new(last_seq, timeout=0.2)      # blocks, no busy spin, no duplicate frames
        if frame is None or seq == last_seq:
            continue
        skipped = seq - last_seq - 1 if last_seq else 0
        last_seq = seq

        now = time.perf_counter()
        if now - last_t < min_dt:                                  # cap fps sent to UI
            continue
        last_t = now

        frame.record_stream(stream)
        with torch.cuda.stream(stream):
            view, (e0, e1, e2) = make_view(frame, stitch, warned)
            img = view.cpu().numpy()                               # D2H of ~1.6 MB, synchronous on this stream
        stream.synchronize()

        box.put({
            "img": img,
            "ts": ts,                                              # reader decode time (monotonic)
            "stitch_ms": e0.elapsed_time(e1),
            "resize_ms": e1.elapsed_time(e2),
            "skipped": skipped,
        })


# ─────────────────────────────── encode + emit stage ──────────────────
def _payload(frame_id, view_id, b64):
    p = {
        "message_id": frame_id,
        "sensor_id": 1,
        "panoramic_view_id": view_id,
        "frame_id": frame_id,
        "aice_epoch": int(time.time() * 1_000_000),
        "no_of_targets": 0,
        "targets": [],
        "image": b64,
    }
    if DEBUG_FIELDS:                      # extra keys can break a strict Java deserializer, so off by default
        p["server_ts_ms"] = time.time() * 1000
    return p


def sender_loop(box, stop):
    last_n = 0
    frame_id = 0
    acc = dict(n=0, stitch=0.0, resize=0.0, enc=0.0, emit=0.0, age=0.0, age_max=0.0, kb=0.0, skipped=0)
    t_report = time.time()

    while not stop.is_set():
        item, n = box.get(last_n, 0.2)
        if item is None or n == last_n:
            continue
        last_n = n

        t0 = time.perf_counter()
        buf = jpeg.encode(item["img"], quality=JPEG_QUALITY, pixel_format=TJPF_RGB)   # nvdec gives RGB, not BGR
        b64 = base64.b64encode(buf).decode()
        t1 = time.perf_counter()

        sio.emit("frame", _payload(frame_id, 1, b64), namespace="/front")
        if ALSO_SEND_REAR:
            sio.emit("frame", _payload(frame_id, 2, b64), namespace="/rear")
        t2 = time.perf_counter()
        frame_id += 1

        age = (time.monotonic() - item["ts"]) * 1000
        acc["n"] += 1
        acc["stitch"] += item["stitch_ms"]
        acc["resize"] += item["resize_ms"]
        acc["enc"] += (t1 - t0) * 1000
        acc["emit"] += (t2 - t1) * 1000
        acc["age"] += age
        acc["age_max"] = max(acc["age_max"], age)
        acc["kb"] += len(b64) / 1024
        acc["skipped"] += item["skipped"]

        if time.time() - t_report >= STATS_EVERY:
            dt = time.time() - t_report
            k = max(acc["n"], 1)
            print(
                f"[server] sent_fps={acc['n']/dt:.1f} | stitch={acc['stitch']/k:.2f}ms resize={acc['resize']/k:.2f}ms "
                f"jpeg+b64={acc['enc']/k:.2f}ms emit={acc['emit']/k:.2f}ms | "
                f"decode->sent age avg={acc['age']/k:.1f}ms max={acc['age_max']:.1f}ms | "
                f"payload={acc['kb']/k:.0f}KB | frames_skipped={acc['skipped']}"
            )
            acc = dict(n=0, stitch=0.0, resize=0.0, enc=0.0, emit=0.0, age=0.0, age_max=0.0, kb=0.0, skipped=0)
            t_report = time.time()


# ─────────────────────────────── main ─────────────────────────────────
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-stitch", action="store_true", help="skip split_concat (diagnose stitching cost)")
    ap.add_argument("--file", default=None, help="offline video instead of RTSP")
    args = ap.parse_args()

    stitch = STITCH and not args.no_stitch
    source_mode = 0 if args.file else 1
    video_path = args.file or VIDEO_PATH

    cam = RTSPReader(url=RTSP_URL, name="cam_rotating", source_mode=source_mode, video_path=video_path)
    stop = threading.Event()
    box = Mailbox()

    print("waiting for first frame...")
    frame, ts, seq = cam.wait_new(last_seq=0, timeout=30.0)
    if frame is None:
        raise RuntimeError("no frame received from camera")
    print(f"first frame {tuple(frame.shape)} {frame.dtype} {frame.device} | stitch={stitch}")

    threading.Thread(target=pipeline_loop, args=(cam, box, stop, stitch), daemon=True, name="gpu").start()
    threading.Thread(target=sender_loop, args=(box, stop), daemon=True, name="sender").start()

    print(f"socket.io server on 0.0.0.0:{PORT}  namespaces /front /rear")
    try:
        run_simple("0.0.0.0", PORT, app, threaded=True, use_reloader=False)
    finally:
        stop.set()
        cam.stop()
